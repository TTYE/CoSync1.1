#' soft-thresholding powers picking
#'
#' As suggested by WGCNA, the 1st number that hists
#' between 0.8-0.9 region should be picked as the soft-threshold
#'
#' @param x - adjacency matrix returned by phaseLockingMatrix, grangerTest or coherenceTest
#' @return  pdf file with R^2 plot and average connectivity
#' @examples
#' #example 1
#' #be aware that this example data is generating a random matirx, so the plot does not match the real situation.  
#' x = replicate(1000, qunif(sort(runif(1000,min=0,max=1)), min = 0, max = 1))
#' x[lower.tri(x)] = t(x)[lower.tri(x)]
#' wgcnaPower(x)
#'
#' @references
#' [1] Langfelder, P. & Horvath, S. WGCNA: an R package for weighted correlation network analysis. BMC Bioinformatics 9, 559 (2008)
#'
#' @export
wgcnaPower <- function(x) {
  # The following setting is important, do not omit.
  # Choose a set of soft-thresholding powers
  powers = c(c(1:10), seq(from = 12, to = 20, by = 2))
  
  if (min(x)<0){
    networkType="signed"
  }else {networkType="unsigned"}
  
  # Call the network topology analysis function
  sft = WGCNA::pickSoftThreshold(x, dataIsExpr = FALSE, networkType = networkType,powerVector = powers, verbose = 5)
  
  return(sft)
  # Plot the results:
  #sizeGrWindow(9, 5)

}


#' WGCNA modules
#'
#' As suggested by WGCNA, the 1st number that hists
#' between 0.8-0.9 region should be picked as the soft-threshold
#'
#' @param x - sychronization index  matrix returned by phaseLockingMatrix, grangerTest or coherenceTest
#' @param softPower - based on the plot of function wgcna_analysis_power, the 1st number that hists between 0.8-0.9 region should be picked as the soft-threshold. If none, use 1.
#' @param cutHeight - the height in cutting the hierarchical tree
#' @return  Hierarchical tree, and the vector indicates the module assignment.
#' @examples
#' #example 1
#' x = replicate(1000, rnorm(1000))
#' wgcna_result=wgcna_analysis(x,5)
#'
#' @references
#' [1] Langfelder, P. & Horvath, S. WGCNA: an R package for weighted correlation network analysis. BMC Bioinformatics 9, 559 (2008)
#'
#' @export
wgcnaAnalysisStaticCut <- function(x, softPower=1,cutHeight=0.95) {

  # Turn adjacency into topological overlap
  TOM = WGCNA::TOMsimilarity(x)
  
  rownames(TOM)=rownames(x)
  colnames(TOM)=colnames(x)
  
  dissTOM = 1 - TOM
  # Call the hierarchical clustering function
  geneTree = hclust(as.dist(dissTOM), method = "average")
  
  static_modules=cutreeStatic(geneTree, cutHeight= cutHeight, minSize = 10)
  
  names(static_modules)=rownames(x)

  return(list("geneTree"=geneTree,"modules"=static_modules))
}

#' WGCNA modules dynamics tree cut
#'
#' As suggested by WGCNA, the 1st number that hists
#' between 0.8-0.9 region should be picked as the soft-threshold
#'
#' @param x - sychronization index  matrix returned by phaseLockingMatrix, grangerTest or coherenceTest
#' @param softPower - based on the plot of function wgcna_analysis_power, the 1st number that hists between 0.8-0.9 region should be picked as the soft-threshold. If none, use 1.
#' @param expr - the expression profile.
#' @return  Hierarchical tree, and the vector indicates the module assignment.
#' @examples
#' #example 1
#' x = replicate(1000, rnorm(1000))
#' wgcna_result=wgcna_analysis(x,5)
#'
#' @references
#' [1] Langfelder, P. & Horvath, S. WGCNA: an R package for weighted correlation network analysis. BMC Bioinformatics 9, 559 (2008)
#'
#' @export
wgcnaAnalysisDynamic <- function(x,expr, softPower=1) {

  # Turn adjacency into topological overlap
  TOM = WGCNA::TOMsimilarity(x)
  
  rownames(TOM)=rownames(x)
  colnames(TOM)=colnames(x)
  
  dissTOM = 1 - TOM
  # Call the hierarchical clustering function
  geneTree = hclust(as.dist(dissTOM), method = "average")
  
  minModuleSize = 30
  # Module identification using dynamic tree cut:
  dynamicMods = cutreeDynamic(dendro = geneTree, distM = dissTOM, deepSplit = 2, pamRespectsDendro = FALSE,minClusterSize = minModuleSize)

  # Convert numeric lables into colors
  dynamicColors = WGCNA::labels2colors(dynamicMods)

  MEDissThres = 0.05
  # Call an automatic merging function
  merge = mergeCloseModules(t(expr), dynamicColors, cutHeight = MEDissThres, verbose = 3)
  # The merged module colors
  dynamic_modules = merge$colors
  
  #plot here
  plotDendroAndColors(geneTree, dynamic_modules, "Dynamic Tree Cut", dendroLabels = FALSE, hang = 0.03, addGuide = TRUE, guideHang = 0.05,main = "Gene dendrogram and module colors")
  
  names(dynamic_modules)=rownames(x)

  return(list("geneTree"=geneTree,"modules"=dynamic_modules))
}



#' Plot modules
#'
#' To visualize modules in graph and in heatmap
#'
#' @param x - co-sychronization matrix returned by phaseLockingMatrix, grangerTest or coherenceTest
#' @param expr - expression profile
#' @param modulColors - color vector return by wgcnaAnalysis
#' @param thisColor - the color of the module to be plotted
#' @param cut - the threshold for the co-sychronization matrix, extacting submatrix that is bigger than this cutoff, and plot the graph.
#' 
#' @return  2 plots and a matrix. First column of the matrix has the connected subgraph ids, second colimn of the matrix has the gene ids.
#' @example
#'
#' @export
ModulePlots <-
  function(x,expr,modules,thisColor = "all",cut = 0.3) {
    
    modulColors= WGCNA::labels2colors(modules)
    names(modulColors)=names(modules)
    
    if (thisColor=="all"){
      this_adj=x
      this_expr=expr[rownames(x),]
    }else{
      #extract the adjacency matrix in the same module
      this_adj = x[names(modulColors[modulColors == thisColor]),
                   names(modulColors[modulColors == thisColor])]
      this_expr = expr[names(modulColors[modulColors == thisColor]),]
    }
    
    
    this_adj[this_adj<cut]=0
    diag(this_adj)=0
    
    #plot the vertices with edges incident to 
    plot_names=names(which(rowSums(this_adj)>0))
    plot_adj=this_adj[plot_names,plot_names]
    
    if (nrow(plot_adj)>300) warning(paste("The size of the graph is", toString(nrow(plot_adj)),
                                          ". The plot may not be abel to bring you any information and it takes a long time to plot out,
                                          try to reduce the cut to a bigger value"))
    
    net = igraph::graph.adjacency(
      as.matrix(plot_adj),mode = "undirected",weighted = TRUE,diag = FALSE
    )
    
    V(net)$size<-igraph::degree(net)
    
    #for phase gamma and coherence, we can set the edge weight this way. Not for granger p-value
    igraph::plot.igraph(
      net,vertex.label = V(net)$name,layout = layout.fruchterman.reingold,
      edge.color = "black",vertex.label.color='black',
      vertex.label.font=1,vertex.label.cex=0.5,
      edge.width = E(net)$weight,main = paste("Module", thisColor)
    )
    
    #heatmap, require library(gplot)
#     heatmap(as.matrix(this_expr),Rowv = TRUE, Colv=FALSE,
#             labRow=FALSE,col=redblue(75),main = paste("Module", thisColor))
    this_expr_scale=t(scale(t(this_expr)))
    this_expr_scale[this_expr_scale > 2.5] = 2.5
    this_expr_scale[this_expr_scale < (-1)*2.5] = -2.5
    this_expr_scale[is.na(this_expr_scale)] = 0
    
    heatmap.2(this_expr_scale,
              col= rev(colorRampPalette(brewer.pal(9, "RdBu"))(100)),
              dendrogram="row",trace="none",key = FALSE, Rowv = TRUE,Colv=FALSE,
              scale = "row",cexCol=0.8,main = paste("Module", thisColor),
              labRow=FALSE)
    
    all_subgraph=decompose.graph(net)
    subgraph_matrix=matrix(0,nrow=nrow(plot_adj),ncol=3)
    colnames(subgraph_matrix)=c(paste("subgraph ID of module",thisColor),"gene ID","degree")
    
    index=1
    for (i in 1:length(all_subgraph)){
      for (id in V(all_subgraph[[i]])$name){
        subgraph_matrix[index,1]=i
        subgraph_matrix[index,2]=id
        subgraph_matrix[index,3]=igraph::degree(all_subgraph[[i]],v=id)
        index=index+1
      }
    }
    
    return(list("subgraph_matrix"=subgraph_matrix,"all_subgraph"=all_subgraph))
    
  }

subGraphPlots<-
  function(expr,subgraph_matrix,all_subgraph,subgraph_id=1){

  net = all_subgraph[[subgraph_id]]
    
    V(net)$size<-igraph::degree(net)
    
    #for phase gamma and coherence, we can set the edge weight this way. Not for granger p-value
    igraph::plot.igraph(
      net,vertex.label = V(net)$name,layout = layout.fruchterman.reingold,
      edge.color = "black",vertex.label.color='black',
      vertex.label.font=1,vertex.label.cex=0.5,
      edge.width = E(net)$weight,main = paste("Module", thisColor)
    )
    
    this_expr=expr[V(net)$name,]
    
    this_expr_scale=t(scale(t(this_expr)))
    this_expr_scale[this_expr_scale > 2.5] = 2.5
    this_expr_scale[this_expr_scale < (-1)*2.5] = -2.5
    this_expr_scale[is.na(this_expr_scale)] = 0
    
    heatmap.2(this_expr_scale,
              col= redblue(100),
              dendrogram="row",trace="none",key = FALSE, Rowv = TRUE,Colv=FALSE,
              scale = "row",cexCol=0.8,main = paste("Module", thisColor),
              labRow=FALSE)
    
  }

#' Output the modules with GO annotation
#'
#' To export modules with GO.
#'
#' @param modules - numeric vector return by wgcnaAnalysis.
#' @return  Table with the module color, gene names, GO annotation and statistics etc.
#' @examples
#'
#' @export
ModuleAnnotation <-
  function(modules) {
    geneList = names(modules)
    #Generate module annotation table
    #Step 3: take the results and output them to an excel file
    #warning:this uses GO.db and AnnotationDBI and the organism specific annotation
    #the inputs are colorlist and genename

    #the actual code converts the hgnc_symbol to entrez id, which is needed to use the GOenrichment analysis
    ensembl <- biomaRt::useMart("ensembl", dataset = "hsapiens_gene_ensembl")
    mapTab <-
      biomaRt::getBM(
        attributes = c("hgnc_symbol", "entrezgene"), filters = "hgnc_symbol", values = geneList, mart = ensembl, uniqueRows =
          FALSE
      )
    #the next three lines remove duplicate rows
    dupRows <-
      union(which(duplicated(mapTab[,1])), which(duplicated(mapTab[,2])))
    entrezIds <- mapTab[-dupRows, 2]
    names(entrezIds) <- mapTab[-dupRows, 1]
    #this matches the resulting entrezIds to their respective genes
    list <-
      lapply(geneList, function(x)
        if (length(which(x == names(entrezIds))) > 0)
          entrezIds[[which(x == names(entrezIds))]])
    #remove any null values and replace with 0
    list1 <- lapply(list, function(x)
      if (is.null(x))
        0
      else
        x);
    list2 = unlist(list1)
    moduleColors = WGCNA::labels2colors(modules)
    names(moduleColors)=names(modules)
    #non matched are returned as 0
    #this is the enrichment analysis, which only takes entrez id
    #it takes the 10 best fit, generally this enrichment is poorer than online ones and should only
    #be used as a preliminary test, not for publications
    GOenr = WGCNA::GOenrichmentAnalysis(moduleColors, list2, nBestP = 10);
    tab = GOenr$bestPTerms[[4]]$enrichment
    return(tab)
  }

#' Output the 2 modules overlaps.
#'
#' To export the number of genes shared between modules.
#'
#' @param modules1 - modules return by wgcnaAnalysis.
#' @param modules2 - modules return by wgcnaAnalysis.
#' @return  A figure and table with the number of overlapping genes, 
#'  correspondence (correspondence= number of overlap/ avergae module size),
#'  size of modules.
#' @examples
#'
#' @export
wgcnaOverlap <- function(modules1,modules2) {
  
  #   #begin the cross comparison
  #   # Isolate the module labels in the order they appear in ordered module eigengenes
  module1Colors=WGCNA::labels2colors(modules1)
  names(module1Colors)=names(modules1)
  
  module2Colors=WGCNA::labels2colors(modules2)
  names(module2Colors)=names(modules2)
  
  # Convert the numeric module labels to color labels
  color_set1= WGCNA::labels2colors(as.numeric(unique(modules1)))
  color_set2 = WGCNA::labels2colors(as.numeric(unique(modules2)))
  # Number of modules
  n_Mod1 = length(color_set1)
  n_Mod2 = length(color_set2)

    # Initialize tables of correspondence and of the corresponding counts
  correspd_table  = matrix(0, nrow = n_Mod1, ncol = n_Mod2);
  count_table = matrix(0, nrow = n_Mod1, ncol = n_Mod2);
  # Execute all pairwaise comparisons
  for (i in 1:n_Mod1)
    for (j in 1:n_Mod2)
    {
      members1 = (module1Colors == color_set1[i]);
      members2 = (module2Colors == color_set2[j]);
      if (sum(members1) > 400 || sum(members2) > 400) {
        correspd_table [i,j] = 0;
      }else{
        correspd_table [i,j] = sum(members1 + members2 == 2) / (0.5 * (sum(members1) +
                                                                        sum(members2)))
      };
      #pTable[i, j] = -log10(fisher.test(members1, members2, alternative = "greater")$p.value);
      count_table[i, j] = sum(module1Colors == color_set1[i] &
                            module2Colors ==
                            color_set2[j])
    }
  
  
  # Marginal counts (really module sizes)
  mod1_totals = apply(count_table, 1, sum)
  mod2_totals = apply(count_table, 2, sum)
  # Actual plotting
  sizeGrWindow(10,7 );
  par(mfrow=c(1,1));
  par(cex = 1.0);
  par(mar=c(8, 10.4, 2.7, 1)+0.3);
  # Use function labeledHeatmap to produce the color-coded table with all the trimmings
  WGCNA::labeledHeatmap(Matrix = t(correspd_table),
                 xLabels = paste(" ", color_set1),
                 yLabels = paste(" ", color_set2),
                 colorLabels = TRUE,
                 xSymbols = paste("mod1",color_set1, mod1_totals, sep=":"),
                 ySymbols = paste("mod2",color_set2, mod2_totals, sep=":"),
                 textMatrix = t(count_table),
                 colors = blueWhiteRed(100)[50:100],
                 main = "overlapping matrix colored by correspondence",
                 cex.text = 1.0, cex.lab = 1.0, setStdMargins = FALSE);
  
  return(list(correspondence=t(correspd_table),counts=t(count_table),
              mod1_totals=mod1_totals,mod2_totals=mod2_totals))
}

#' Output the 2 modules overlaps.
#'
#' To export the number of genes shared between modules.
#'
#' @param modules - numeric color vector return by wgcnaAnalysis.
#' @param selectColor - celcet the color of the module to perform Go enrichment analysis
#' @param identifier - default is "symbol". One in  c("Entrez", GenBank, Alias, Ensembl, GeneSymbol", "GeneName" and "UniGene"). Refer to topGO. 
#' @param species - "Human" or "Mouse"
#' @param pvalue - export the GO terms with p-value smaller than this number
#' @param fileTree - TRUE if you wish to export the GO tree
#' @param numSigTerm - a parameter past to topGO function printGraph, determines how many top GO terms will be plotted in rectangle.
#' @return  GO enrichment result, and the tree structure GO plot with significant GO terms highlighted in red and orange colors. The pdf file of the tree will be saved in the working directory.
#' @examples
#'
#' @export
topGOanalysis <- function(modules, selectColor="blue", identifier="symbol", species="Human", pvalue=0.05, fileTree=TRUE, numSigTerm=3) {
  geneColors=WGCNA::labels2colors(modules)
  names(geneColors)=names(modules)
  if (species == "Human") {
    mapdb <- "org.Hs.eg.db"      
  } else if (species == "Mouse") {
    mapdb <- "org.Mm.eg.db"      
  }         
  res <- list()
  
  allgene <- names(geneColors)
  inputgene <- allgene[geneColors==selectColor]
  ##unique and remove 0
  allgene_unique<-setdiff(unique(allgene), 0)
  inputgene_unique<-setdiff(unique(inputgene), 0)
  
  geneList <- factor(as.integer(allgene_unique %in% inputgene_unique))
  names(geneList) <- allgene_unique
  
  #prepare the data
  GOdata <- new("topGOdata", ontology = "BP", allGenes = geneList, annot = annFUN.org, mapping = mapdb, ID = identifier)
  
  resultFisher <- topGO::runTest(GOdata, algorithm = "classic", statistic = "fisher")
  goscore<-sort(score(resultFisher))
  

  if(fileTree){
    #if (!exists(numSigTerm)){
    #  numSigTerm<-5
    #}

    topGO::showSigOfNodes(GOdata, score(resultFisher), firstSigNodes = numSigTerm, useInfo = 'all')
  
    topGO::printGraph(GOdata, resultFisher, firstSigNodes = numSigTerm, fn.prefix = fileTree, useInfo = "all", pdfSW = TRUE)

    }

  goscore=goscore[goscore<=pvalue]
  res= matrix( rep(0, length(goscore)*3), ncol=3) 
  colnames(res)<-c("GOterm", "GODesc", "pValue")
  for (i in 1:length(goscore)){
    res[i,1]=names(goscore)[i][1]
    res[i,2]=Term(names(goscore)[i][1])
    res[i,3]=goscore[i]
  }
  return(res)
}


